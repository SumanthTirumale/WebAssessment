# Traffic Monitor
Web Assessment is a assessment application developed using python that allows to audit HTTP and HTTPS requests for 
finding known vulnerabilities for embedded web servers. 


## Installation

* Download the package from [dist](https://github.com/SumanthTirumale/WebAssessment/tree/master/dist) directory  
* Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Web Assessment

```bash
pip install traffic_monitor-X.X.X-py3-none-any.whl
```

## Usage
Type webassessment from command line
```batch
webassessment
```


## License
[MIT](https://choosealicense.com/licenses/mit/)